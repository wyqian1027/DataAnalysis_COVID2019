# Novel Coronavirus 2019 Time Series Data
The time series data is derived from the daily case reports, and will be updated twice daily.
